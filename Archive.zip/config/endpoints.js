
exports.prod = "https://wboardserver.herokuapp.com/";
exports.dev = "http://localhost:3000";
exports.email_user = 'XrzgeVJdQu6wvBVR3lWuUw';
exports.email_key = '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';